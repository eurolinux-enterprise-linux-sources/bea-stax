package com.wutka.dtd;

public interface EntityExpansion
{
    public DTDEntity expandEntity(String name);
}
